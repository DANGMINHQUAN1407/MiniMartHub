﻿using DAL.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Repo
{
    public class AccountRepo
    {
        private Prn212block3WContext _context;
       
        public Account? GetAccount(string email, string password)
        {
            _context = new Prn212block3WContext();

            return _context.Accounts.FirstOrDefault(x => x.Email == email && x.Password == password);
        }
        public List<Account> GetAccounts()
        {
            _context = new Prn212block3WContext();

            return _context.Accounts.Include(x => x.RoleNavigation).ToList();
        }
        public void DeleteAccount(Account account)
        {
            _context = new Prn212block3WContext();

            _context.Accounts.Remove(account);
            _context.SaveChanges();
        }
        public void CreateAccount(Account account)
        {
            _context = new Prn212block3WContext();

            _context.Accounts.Add(account);
            _context.SaveChanges();
        }
        public void UpdateAccount(Account account)
        {
            _context = new Prn212block3WContext();

            _context.Accounts.Update(account);
            _context.SaveChanges();
        }
        public List<Account> SearchAccounts(string search)
        {
            _context = new();
            return _context.Accounts.Where(x => x.Name.Trim().ToUpper().Contains(search.Trim().ToUpper())).Include(x => x.RoleNavigation).ToList();
        }
        public bool IsExistEmail(string email)
        {
            _context = new Prn212block3WContext();

            return _context.Accounts.Any(x => x.Email == email);
        }
        public bool IsExistPhoneNumber(int phoneNumber)
        {
            _context = new Prn212block3WContext();

            return _context.Accounts.Any(x => x.PhoneNumber == phoneNumber);
        }
    }
}
