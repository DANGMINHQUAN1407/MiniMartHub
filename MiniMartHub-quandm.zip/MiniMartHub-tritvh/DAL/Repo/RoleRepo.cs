﻿using DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Repo
{
    public class RoleRepo
    {
        private Prn212block3WContext _context;
        public RoleRepo()
        {
            _context = new Prn212block3WContext();
        }
        public List<Role> GetRoles()
        {
            return _context.Roles
                  .Where(role => !role.Name.Equals("ADMIN"))
                  .ToList();
        }
    }
}
