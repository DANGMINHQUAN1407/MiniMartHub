﻿using DAL.Entities;
using DAL.utils;
using QRCoder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Repo
{
    public class ProductRepo
    {
        private Prn212block3WContext _context;

        public List<Product> GetAllProducts()
        {
            _context = new Prn212block3WContext();
            return _context.Products.Where(p => p.Status == "Active").ToList();
        }

        public void Update(Product product)
        {
            _context = new Prn212block3WContext();
            _context.Products.Update(product);
            _context.SaveChanges();
        }

        public Product? GetProductById(int id)
        {
            _context = new Prn212block3WContext();
            return _context.Products.FirstOrDefault(p => p.Id == id);
        }
        //public void Add(Product product)
        //{
        //    _context = new Prn212block3WContext();
        //    _context.Products.Add(product);
           
        //    _context.SaveChanges();
           
        //}
        public bool UpdateProductQuantity(int productId, int newQuantity)
        {
            _context = new Prn212block3WContext();
            var product = _context.Products.FirstOrDefault(p => p.Id == productId);
            if (product == null) return false;

            product.QuantityInStorage = newQuantity;
            return _context.SaveChanges() > 0;
        }

        public List<Product> SearchProductsByName(string searchTerm)
        {
            _context = new Prn212block3WContext();
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                return GetAllProducts();
            }

            return _context.Products
                .Where(p => p.Status == "Active" &&
                           p.Name.Contains(searchTerm))
                .ToList();
        }

        //public List<Product> SearchProductsByPriceRange(int minPrice, int maxPrice)
        //{
        //    return _context.Products
        //        .Where(p => p.Status == "Active" &&
        //                   p.Price >= minPrice &&
        //                   p.Price <= maxPrice)
        //        .ToList();
        //}

        public List<Product> SearchProducts(string searchTerm = "", int? minPrice = null, int? maxPrice = null)
        {
            _context = new Prn212block3WContext();
            var query = _context.Products.Where(p => p.Status == "Active");

            // Filter by name if provided
            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                query = query.Where(p => p.Name.Contains(searchTerm));
            }

            //// Filter by price range if provided
            //if (minPrice.HasValue)
            //{
            //    query = query.Where(p => p.Price >= minPrice.Value);
            //}

            //if (maxPrice.HasValue)
            //{
            //    query = query.Where(p => p.Price <= maxPrice.Value);
            //}

            return query.ToList();
        }

        public List<Product> GetAll()
        {
            _context = new Prn212block3WContext();
            return _context.Products.ToList();
        }

        public async Task<Product> AddWithQrAsync(Product product)
        {
            _context = new Prn212block3WContext();

            await _context.Products.AddAsync(product);
            await _context.SaveChangesAsync();                    // có Id

            var fileName = await QRCodeService.GenerateQRCodeAsync(product.Id, product.Name);
            product.QrimageUrl = fileName;

            await _context.SaveChangesAsync();                    // cập nhật QrimageUrl
            return product;
        }
    }
}
