﻿using DAL.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Repo
{
    public class OrderRepo
    {
        private Prn212block3WContext _context;

        public int CreateOrder(Order order)
        {
            _context = new Prn212block3WContext();
            _context.Orders.Add(order);
            _context.SaveChanges();
            return order.Id;
        }

        public bool AddOrderDetail(OrderDetail orderDetail)
        {
            _context = new Prn212block3WContext();
            _context.OrderDetails.Add(orderDetail);
            return _context.SaveChanges() > 0;
        }

        public bool AddOrderDetails(List<OrderDetail> orderDetails)
        {
            _context = new Prn212block3WContext();
            _context.OrderDetails.AddRange(orderDetails);
            return _context.SaveChanges() > 0;
        }

        public List<Order> GetAllOrders()
        {
            _context = new Prn212block3WContext();
            return _context.Orders.OrderByDescending(o => o.CreatedDate).Include("CreatedByNavigation").ToList();
        }

        public Order? GetOrderById(int id)
        {
            _context = new Prn212block3WContext();
            return _context.Orders.FirstOrDefault(o => o.Id == id);
        }

        public List<OrderDetail> GetOrderDetails(int orderId)
        {
            _context = new Prn212block3WContext();
            return _context.OrderDetails.Where(od => od.OrderId == orderId).ToList();
        }

        public bool DeleteOrder(int orderId)
        {
            _context = new Prn212block3WContext();
            try
            {
                var order = _context.Orders.FirstOrDefault(o => o.Id == orderId);
                if (order == null)
                {
                    System.Diagnostics.Debug.WriteLine($"Order {orderId} not found");
                    return false;
                }

                _context.Database.ExecuteSqlRaw("DELETE FROM OrderDetail WHERE order_id = {0}", orderId);

                _context.Database.ExecuteSqlRaw("DELETE FROM [Order] WHERE id = {0}", orderId);

                System.Diagnostics.Debug.WriteLine($"Successfully deleted order {orderId}");
                return true;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error deleting order {orderId}: {ex.Message}");
                if (ex.InnerException != null)
                {
                    System.Diagnostics.Debug.WriteLine($"Inner exception: {ex.InnerException.Message}");
                }
                return false;
            }
        }

        public void UpdateOrder(Order? order)
        {
            _context = new();
            _context.Orders.Update(order);
            _context.SaveChanges();
        }

        public List<Order> GetOrdersByDateRange(DateTime fromDate, DateTime toDate)
        {
            _context = new();

            return _context.Orders
                .Include(o => o.OrderDetails)
                .ThenInclude(od => od.Product)
                .Where(o => o.CreatedDate >= fromDate && o.CreatedDate <= toDate)
                .OrderByDescending(o => o.CreatedDate)
                .ToList();
        }

    }
}
