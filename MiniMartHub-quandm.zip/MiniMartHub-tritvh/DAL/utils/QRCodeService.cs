﻿using QRCoder;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.utils
{
    public class QRCodeService
    {
        public static async Task<string> GenerateQRCodeAsync(int productId, string productName, CancellationToken ct = default)
        {
            try
            {
                using var qrGenerator = new QRCodeGenerator();
                string qrContent = productId.ToString();

                using QRCodeData qrCodeData = qrGenerator.CreateQrCode(qrContent, QRCodeGenerator.ECCLevel.Q);

                // Tạo ảnh QR trên threadpool để tránh block UI
                byte[] qrCodeBytes = await Task.Run(() =>
                {
                    using var png = new PngByteQRCode(qrCodeData);
                    return png.GetGraphic(20);
                }, ct);

                string qrFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "QRCodes");
                Directory.CreateDirectory(qrFolder); // OK khi chạy sync

                string fileName = $"qr_{productId}.png";
                string filePath = Path.Combine(qrFolder, fileName);

                await File.WriteAllBytesAsync(filePath, qrCodeBytes, ct);

                return fileName; // chỉ lưu tên file vào DB
            }
            catch
            {
                // có thể log ex nếu cần
                return $"qr_{productId}.png";
            }
        }

        public static string GetQRCodeFullPath(string fileName)
        {
            string qrFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "QRCodes");
            return Path.Combine(qrFolder, fileName);
        }
       
            public static string GetQRCodeFolder()
                => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "QRCodes");
        
        public static string GetQRCodeContent(int productId, string productName)
        {
            return $"Product Information:\nID: {productId}\nName: {productName}\n\nScan this QR code to view product details.";
        }
    }
}
