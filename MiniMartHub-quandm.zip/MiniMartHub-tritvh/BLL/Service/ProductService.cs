﻿using ClosedXML.Excel;
using ClosedXML.Excel.Drawings;
using DAL.Entities;
using DAL.Repo;
using DAL.utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Service
{
    public class ProductService
    {
        private ProductRepo _repo;

        public ProductService()
        {
            _repo = new ProductRepo();
        }

        public List<Product> GetAllAvailableProducts()
        {
            return _repo.GetAllProducts().Where(p => p.QuantityInStorage > 0).ToList();
        }

        public Product? GetProductById(int id)
        {
            return _repo.GetProductById(id);
        }

        public bool IsProductAvailable(int productId, int requiredQuantity)
        {
            var product = _repo.GetProductById(productId);
            return product != null && product.QuantityInStorage >= requiredQuantity;
        }

        public bool UpdateProductStock(int productId, int soldQuantity)
        {
            var product = _repo.GetProductById(productId);
            if (product == null || product.QuantityInStorage < soldQuantity)
                return false;

            int newQuantity = product.QuantityInStorage.Value - soldQuantity;

            return _repo.UpdateProductQuantity(productId, newQuantity);
        }
        //public void Add(Product product)
        //{
        //    _repo.Add(product);
        //    string qr =QRCodeService.GenerateQRCode(product.Id, product.Name);
        //    _repo.Save(product);
        //}
        public void Update(Product product)
        {
            _repo.Update(product);
        }

        public bool RestoreProductStock(int productId, int returnQuantity)
        {
            var product = _repo.GetProductById(productId);
            if (product == null) return false;

            int newQuantity = (product.QuantityInStorage ?? 0) + returnQuantity;
            return _repo.UpdateProductQuantity(productId, newQuantity);
        }

        public List<Product> SearchProductsByName(string searchTerm)
        {
            var searchResults = _repo.SearchProductsByName(searchTerm);
            return searchResults.Where(p => p.QuantityInStorage > 0).ToList();
        }

        public List<Product> SearchAvailableProducts(string searchTerm = "", int? minPrice = null, int? maxPrice = null)
        {
            var products = GetAllAvailableProducts();

            // Filter by name if search term provided
            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                products = products.Where(p => p.Name.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            // Filter by price range if provided
            if (minPrice.HasValue)
            {
                products = products.Where(p => p.Price >= minPrice.Value).ToList();
            }

            if (maxPrice.HasValue)
            {
                products = products.Where(p => p.Price <= maxPrice.Value).ToList();
            }

            return products;
        }

        public List<Product> GetProductsByStatus(string status = "Active")
        {
            var allProducts = _repo.GetAllProducts();
            return allProducts.Where(p => p.Status == status && p.QuantityInStorage > 0).ToList();
        }

        public List<Product> GetProducts()
        {
            return _repo.GetAll();
        }

        public Task<Product> AddWithQrAsync(Product product)
      => _repo.AddWithQrAsync(product);


        static double PixelsToColumnWidth(int pixels) => (pixels - 5) / 7.0;            // xấp xỉ
        static double PixelsToRowHeight(int pixels) => pixels * 72.0 / 96.0;          // px -> points

        public void ExportProductsToExcelWithQr(string filePath)
        {
            var products = _repo.GetAllProducts();

            using var wb = new XLWorkbook();
            var ws = wb.Worksheets.Add("Products");

            // Header
            ws.Cell(1, 1).Value = "Id";
            ws.Cell(1, 2).Value = "Name";
            ws.Cell(1, 3).Value = "Price";
            ws.Cell(1, 4).Value = "QuantityInStorage";
            ws.Cell(1, 5).Value = "Status";
            ws.Cell(1, 6).Value = "QR";
            ws.Range("A1:F1").Style.Font.Bold = true;
            ws.SheetView.FreezeRows(1);

            // Định dạng số & tự dãn cột chữ
            ws.Column(3).Style.NumberFormat.Format = "#,##0";
            ws.Columns(1, 5).AdjustToContents();

            // Kích thước mong muốn cho ô QR (pixel)
            const int QR_SIZE_PX = 96;               // đổi nếu muốn lớn/nhỏ hơn
            const int MARGIN_PX = 2;

            // Cột F đủ rộng cho ảnh + margin
            ws.Column(6).Width = PixelsToColumnWidth(QR_SIZE_PX + MARGIN_PX * 2);

            int r = 2;
            foreach (var p in products)
            {
                ws.Cell(r, 1).Value = p.Id;
                ws.Cell(r, 2).Value = p.Name;
                ws.Cell(r, 3).Value = p.Price;
                ws.Cell(r, 4).Value = p.QuantityInStorage;
                ws.Cell(r, 5).Value = p.Status;

                // Đặt chiều cao dòng theo pixel mong muốn
                ws.Row(r).Height = PixelsToRowHeight(QR_SIZE_PX + MARGIN_PX * 2);

                // Chèn ảnh vào ô F{r}
                var fullPath = QRCodeService.GetQRCodeFullPath(p.QrimageUrl);
                if (File.Exists(fullPath))
                {
                    var cell = ws.Cell(r, 6);
                    var pic = ws.AddPicture(fullPath)
                                .WithPlacement(XLPicturePlacement.MoveAndSize) // di chuyển & co giãn theo ô
                                .MoveTo(cell, MARGIN_PX, MARGIN_PX)             // neo trên-trái trong ô F{r}
                                .WithSize(QR_SIZE_PX, QR_SIZE_PX);              // vừa khít bên trong ô
                                                                                // pic.Name = $"QR_{p.Id}"; // (tuỳ chọn) đặt tên shape
                }
                else
                {
                    ws.Cell(r, 6).Value = "N/A";
                }

                r++;
            }

            wb.SaveAs(filePath);
        }
    }
}
