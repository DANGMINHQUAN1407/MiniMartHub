﻿using DAL.Entities;
using DAL.Repo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Service
{
    public class OrderService
    {
        private OrderRepo _orderRepo;
        private ProductService _productService;
        private EmailService _emailService = new();
        private AccountService _accountService = new();

        public OrderService()
        {
            _orderRepo = new OrderRepo();
            _productService = new ProductService();
        }

        public bool CreateOrder(int createdBy, List<CartItem> cartItems)
        {
            try
            {
                // Validate stock availability
                foreach (var item in cartItems)
                {
                    if (!_productService.IsProductAvailable(item.ProductId, item.Quantity))
                    {
                        return false;
                    }
                }

                // Calculate total price
                int totalPrice = 0;
                foreach (var item in cartItems)
                {
                    var product = _productService.GetProductById(item.ProductId);
                    if (product != null)
                    {
                        totalPrice += product.Price * item.Quantity;
                    }
                }

                // Create order
                var order = new Order
                {
                    TotalPrice = totalPrice,
                    CreatedDate = DateTime.Now,
                    CreatedBy = createdBy,
                    Status = "Not Paid"
                };

                int orderId = _orderRepo.CreateOrder(order);

                // Create order details
                var orderDetails = new List<OrderDetail>();
                foreach (var item in cartItems)
                {
                    var product = _productService.GetProductById(item.ProductId);
                    if (product != null)
                    {
                        orderDetails.Add(new OrderDetail
                        {
                            OrderId = orderId,
                            ProductId = item.ProductId,
                            Quantity = item.Quantity,
                            TotalPriceOfProduct = product.Price * item.Quantity
                        });

                    }
                }

                return _orderRepo.AddOrderDetails(orderDetails);
            }
            catch
            {
                return false;
            }
        }

        public List<Order> GetAllOrders()
        {
            return _orderRepo.GetAllOrders();
        }

        public Order? GetOrderById(int id)
        {
            return _orderRepo.GetOrderById(id);
        }

        public List<OrderDetail> GetOrderDetails(int orderId)
        {
            return _orderRepo.GetOrderDetails(orderId);
        }

        public bool DeleteOrder(int orderId)
        {
            try
            {
                // Get order details before deleting to restore stock
                var orderDetails = GetOrderDetails(orderId);

                // Delete the order (this will also delete order details due to raw SQL in OrderRepo)
                bool deleteSuccess = _orderRepo.DeleteOrder(orderId);

                if (deleteSuccess)
                {
                    // Restore product stock
                    foreach (var detail in orderDetails)
                    {
                        _productService.RestoreProductStock(detail.ProductId, detail.Quantity);
                    }
                }

                return deleteSuccess;
            }
            catch
            {
                return false;
            }
        }

        public bool CompleteOrderAndUpdateStock(int orderId)
        {
            try
            {
                // Get order details
                var orderDetails = GetOrderDetails(orderId);
                if (orderDetails.Count == 0)
                {
                    return false;
                }

                List<Product> productsSoonEnd = new List<Product>();
                // Restore stock for each product in the order
                foreach (var detail in orderDetails)
                {
                    bool updateSuccess = _productService.UpdateProductStock(detail.ProductId, detail.Quantity);
                    if (!updateSuccess)
                    {
                        System.Diagnostics.Debug.WriteLine($"Failed to update stock for product {detail.ProductId}");
                        return false; // Nếu không trừ được stock thì fail
                    }
                    var product = _productService.GetProductById(detail.ProductId);
                    if (product != null)
                    {
                        if (product.QuantityInStorage < 10 && product.QuantityInStorage >0)
                        {
                            productsSoonEnd.Add(product);
                        }
                        if (product.QuantityInStorage == 0)
                        {
                            product.Status = "Inactive";
                            _productService.Update(product);
                        }
                    }
                   
                }
                if (productsSoonEnd.Count != 0)
                {
                    var subject = $" Cảnh báo hàng hóa sắp hết - {productsSoonEnd.Count()} sản phẩm cần nhập thêm";
                    var body = _emailService.CreateLowStockAlertBody(productsSoonEnd, DateTime.Now);
                    var accounts = _accountService.GetAccounts();
                    foreach (var account in accounts) {
                       if(account.Role == 3)
                        _ = _emailService.SendEmailAsync(account.Email, subject, body);
                    }
                }
                var order = GetOrderById(orderId);
                order.Status = "Paid";
                _orderRepo.UpdateOrder(order);
                return true;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error restocking order {orderId}: {ex.Message}");
                return false;
            }
        }

        public List<Order> GetOrdersByDateRange(DateTime fromDate, DateTime toDate)
        {
            return _orderRepo.GetOrdersByDateRange(fromDate, toDate);
        }

    }

    // Helper class for cart functionality
    public class CartItem
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public int Price { get; set; }
        public int Quantity { get; set; }
        public int TotalPrice => Price * Quantity;
    }
}
