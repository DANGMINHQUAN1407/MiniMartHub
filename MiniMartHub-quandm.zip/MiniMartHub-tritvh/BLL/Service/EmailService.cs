﻿using DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using BLL.Common;

namespace BLL.Service
{
    internal class EmailService
    {
        private readonly string _smtpServer;
        private readonly int _smtpPort;
        private readonly string _emailUsername;
        private readonly string _emailPassword;
        private readonly string _fromEmail;
        private readonly string _fromDisplayName;
        private readonly bool _enableSsl;

        public EmailService()
        {

            _smtpServer = ConfigurationHelper.GetEmailSetting("SmtpServer");
            _smtpPort = int.Parse(ConfigurationHelper.GetEmailSetting("SmtpPort") ?? "587");
            _emailUsername = ConfigurationHelper.GetEmailSetting("EmailUsername");
            _emailPassword = ConfigurationHelper.GetEmailSetting("EmailPassword");
            _fromEmail = ConfigurationHelper.GetEmailSetting("FromEmail");
            _fromDisplayName = ConfigurationHelper.GetEmailSetting("FromDisplayName");
            _enableSsl = bool.Parse(ConfigurationHelper.GetEmailSetting("EnableSsl") ?? "true");

            if (string.IsNullOrEmpty(_emailUsername) || string.IsNullOrEmpty(_emailPassword))
            {
                throw new InvalidOperationException("Cấu hình email bị thiếu trong appsettings.json");
            }
        }

        public async Task<bool> SendEmailAsync(string toEmail, string subject, string body)
        {
            try
            {
                using var client = new SmtpClient(_smtpServer, _smtpPort)
                {
                    Credentials = new NetworkCredential(_emailUsername, _emailPassword),
                    EnableSsl = _enableSsl
                };

                var mailMessage = new MailMessage
                {
                    From = new MailAddress(_fromEmail, _fromDisplayName),
                    Subject = subject,
                    Body = body,
                    IsBodyHtml = true
                };

                mailMessage.To.Add(toEmail);

                await client.SendMailAsync(mailMessage);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Gửi email thất bại: {ex.Message}");
                return false;
            }
        }



        public string CreateLowStockAlertBody(List<Product> lowStockProducts, DateTime checkDate)
        {
            var productList = string.Join("", lowStockProducts.Select(p =>
                $"<li><strong>{p.Name}</strong>: {p.QuantityInStorage ?? 0} sản phẩm</li>"));

            return $@"
                <html>
                <body>
                    <h2> Cảnh báo hàng hóa sắp hết</h2>
                    <p>Kính gửi Quản lý,</p>
                    <p>Đây là thông báo tự động từ hệ thống MiniMart về tình trạng hàng hóa trong kho.</p>
                    
                    <div style='background-color: #fff3cd; padding: 15px; border-left: 4px solid #ffc107; margin: 20px 0;'>
                        <h3> Các sản phẩm cần nhập thêm (< 10 sản phẩm):</h3>
                        <ul style='margin: 10px 0;'>
                            {productList}
                        </ul>
                        <p><strong>Thời gian kiểm tra:</strong> {checkDate:dd/MM/yyyy HH:mm}</p>
                    </div>
                     
                    <p>Vui lòng xem xét việc nhập thêm hàng hóa để đảm bảo không bị thiếu hàng.</p>
                    
                    <p>Trân trọng,<br/>
                    Hệ thống quản lý MiniMart</p>
                </body>
                </html>";
        }
    }
}
