﻿using DAL.Entities;
using DAL.Repo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Service
{
    public class AccountService
    {
        private AccountRepo _repo;
        public AccountService()
        {
            _repo = new AccountRepo();
        }
        public Account? GetAccount(string email, string password)
        {
            return _repo.GetAccount(email, password);
        }

        public void CreateAccount(Account account)
        {
            _repo.CreateAccount(account);
        }
        public List<Account> GetAccounts()
        {
            return _repo.GetAccounts();
        }
        public void UpdateAccount(Account account)
        {
            _repo.UpdateAccount(account);
        }
        public List<Account> SearchAccounts(string txtSearch)
        {
            return _repo.SearchAccounts(txtSearch);
        }
        public void DeleteAccount(Account account)
        {
            _repo.DeleteAccount(account);
        } 
        public bool IsExistPhoneNumber(int phoneNumber)
        {
            return _repo.IsExistPhoneNumber(phoneNumber);
        }
        public bool IsExistEmail(string email)
        {
            return _repo.IsExistEmail(email);
        }
    }
}
