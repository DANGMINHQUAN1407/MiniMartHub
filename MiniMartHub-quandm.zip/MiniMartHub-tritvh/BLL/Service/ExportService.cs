﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Service
{
    using DAL.Entities;
    using OfficeOpenXml;
    using OfficeOpenXml.Drawing.Chart;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    namespace BLL.Service
    {
        public class ExportService
        {
            public ExportService()
            {

            }

            public string ExportRevenueToCsv(List<Order> orders, DateTime fromDate, DateTime toDate)
            {
                var csv = new StringBuilder();

                var totalRevenue = orders.Sum(o => o.TotalPrice);
                var totalOrders = orders.Count;

                csv.AppendLine("=== REVENUE REPORT ===");
                csv.AppendLine($"Period:,{fromDate:dd/MM/yyyy} - {toDate:dd/MM/yyyy}");
                csv.AppendLine($"Total Revenue:,{totalRevenue:C}");
                csv.AppendLine($"Total Orders:,{totalOrders}");
                csv.AppendLine($"Average Order Value:,{(totalOrders > 0 ? totalRevenue / totalOrders : 0):C}");
                csv.AppendLine();

                csv.AppendLine("Order ID,Date,Total Price,Created By,Items Count");
                foreach (var order in orders)
                {
                    csv.AppendLine($"{order.Id},{order.CreatedDate:dd/MM/yyyy},{order.TotalPrice:C},{order.CreatedBy},{order.OrderDetails?.Count ?? 0}");
                }

                return csv.ToString();
            }

            public byte[] ExportRevenueToExcel(List<Order> orders, DateTime fromDate, DateTime toDate)
            {
                ExcelPackage.LicenseContext = OfficeOpenXml.LicenseContext.NonCommercial;

                using var package = new ExcelPackage();

                CreateSummaryWithCharts(package, orders, fromDate, toDate);
                CreateDetailedDataSheet(package, orders);

                return package.GetAsByteArray();
            }


            private void CreateSummaryWithCharts(ExcelPackage package, List<Order> orders, DateTime fromDate, DateTime toDate)
            {
                var worksheet = package.Workbook.Worksheets.Add("Revenue Dashboard");

                var totalRevenue = orders.Sum(o => o.TotalPrice);
                var totalOrders = orders.Count;

                worksheet.Cells["A1"].Value = "REVENUE DASHBOARD";
                worksheet.Cells["A1"].Style.Font.Size = 18;
                worksheet.Cells["A1"].Style.Font.Bold = true;

                worksheet.Cells["A2"].Value = $"Period: {fromDate:dd/MM/yyyy} - {toDate:dd/MM/yyyy}";
                worksheet.Cells["A3"].Value = $"Total Revenue: {totalRevenue:C}";
                worksheet.Cells["A4"].Value = $"Total Orders: {totalOrders}";

                //CreateDailyRevenueChart(worksheet, orders);
                CreateTopProductsChart(worksheet, orders);
            }

            //private void CreateDailyRevenueChart(ExcelWorksheet worksheet, List<Order> orders)
            //{
            //    var dailyRevenue = orders
            //        .GroupBy(o => o.CreatedDate.Date)
            //        .Select(g => new
            //        {
            //            Date = g.Key,
            //            Revenue = g.Sum(o => o.TotalPrice)
            //        })
            //        .OrderBy(x => x.Date)
            //        .ToList();

            //    int startRow = 6;
            //    worksheet.Cells[startRow, 1].Value = "Date";
            //    worksheet.Cells[startRow, 2].Value = "Daily Revenue";

            //    for (int i = 0; i < dailyRevenue.Count; i++)
            //    {
            //        worksheet.Cells[startRow + 1 + i, 1].Value = dailyRevenue[i].Date;
            //        worksheet.Cells[startRow + 1 + i, 1].Style.Numberformat.Format = "dd/mm/yyyy";
            //        worksheet.Cells[startRow + 1 + i, 2].Value = dailyRevenue[i].Revenue;
            //    }

            //    var chart1 = worksheet.Drawings.AddChart("DailyRevenueChart", eChartType.Line);
            //    chart1.Title.Text = "Daily Revenue Trend";
            //    chart1.SetPosition(5, 0, 4, 0); 
            //    chart1.SetSize(400, 300);

            //    var xRange = worksheet.Cells[startRow + 1, 1, startRow + dailyRevenue.Count, 1]; 
            //    var yRange = worksheet.Cells[startRow + 1, 2, startRow + dailyRevenue.Count, 2]; 
            //    chart1.Series.Add(yRange, xRange); 

            //    chart1.XAxis.Title.Text = "Date";
            //    chart1.YAxis.Title.Text = "Revenue (VND)";
            //    chart1.Legend.Position = eLegendPosition.Bottom;
            //}

            private void CreateTopProductsChart(ExcelWorksheet worksheet, List<Order> orders)
            {
                var topProducts = orders
                    .Where(o => o.OrderDetails != null)
                    .SelectMany(o => o.OrderDetails)
                    .Where(od => od.Product != null)
                    .GroupBy(od => od.Product.Name)
                    .Select(g => new
                    {
                        ProductName = g.Key,
                        TotalRevenue = g.Sum(od => od.TotalPriceOfProduct)
                    })
                    .Where(x => x.TotalRevenue > 0)
                    .OrderByDescending(x => x.TotalRevenue)
                    .Take(5)
                    .ToList();

                if (!topProducts.Any()) return;

                int startRow = 6;
                int startCol = 8;

                worksheet.Cells[startRow, startCol].Value = "Product Name";
                worksheet.Cells[startRow, startCol + 1].Value = "Revenue";

                for (int i = 0; i < topProducts.Count; i++)
                {
                    worksheet.Cells[startRow + 1 + i, startCol].Value = topProducts[i].ProductName;
                    worksheet.Cells[startRow + 1 + i, startCol + 1].Value = topProducts[i].TotalRevenue;
                }

                var chart2 = worksheet.Drawings.AddChart("TopProductsChart", eChartType.Pie);
                chart2.Title.Text = " Top 5 Products by Revenue";
                chart2.SetPosition(5, 0, 10, 0);
                chart2.SetSize(400, 300);

                var valuesRange = worksheet.Cells[startRow + 1, startCol + 1, startRow + topProducts.Count, startCol + 1];
                var categoriesRange = worksheet.Cells[startRow + 1, startCol, startRow + topProducts.Count, startCol];

                var series = chart2.Series.Add(valuesRange, categoriesRange);
                series.Header = "Revenue";

                chart2.Legend.Position = eLegendPosition.Right;

                var pieChart = chart2 as ExcelPieChart;
                if (pieChart != null)
                {
                    pieChart.DataLabel.ShowCategory = true;
                    pieChart.DataLabel.ShowPercent = true;
                    pieChart.DataLabel.ShowValue = false;
                }
            }

            private void CreateDetailedDataSheet(ExcelPackage package, List<Order> orders)
            {
                var worksheet = package.Workbook.Worksheets.Add("Detailed Orders");

                worksheet.Cells["A1"].Value = "Order ID";
                worksheet.Cells["B1"].Value = "Date";
                worksheet.Cells["C1"].Value = "Total Price";
                worksheet.Cells["D1"].Value = "Created By";
                worksheet.Cells["E1"].Value = "Items Count";

                using (var range = worksheet.Cells["A1:E1"])
                {
                    range.Style.Font.Bold = true;
                    range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                    range.Style.Fill.BackgroundColor.SetColor(Color.LightGray);
                }

                for (int i = 0; i < orders.Count; i++)
                {
                    var row = i + 2;
                    var order = orders[i];

                    worksheet.Cells[row, 1].Value = order.Id;
                    worksheet.Cells[row, 2].Value = order.CreatedDate;
                    worksheet.Cells[row, 2].Style.Numberformat.Format = "dd/mm/yyyy";
                    worksheet.Cells[row, 3].Value = order.TotalPrice;
                    worksheet.Cells[row, 3].Style.Numberformat.Format = "#,##0 ₫";
                    worksheet.Cells[row, 4].Value = order.CreatedBy;
                    worksheet.Cells[row, 5].Value = order.OrderDetails?.Count ?? 0;
                }

                worksheet.Cells.AutoFitColumns();
            }
        }
    }

}
