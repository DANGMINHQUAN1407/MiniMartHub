﻿using BLL.Service;
using DAL.Entities;
using OpenCvSharp;
using OpenCvSharp.Extensions;        // Mat <-> System.Drawing.Bitmap
using OpenCvSharp.WpfExtensions;     // Mat -> BitmapSource (WPF)
using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using ZXing;
using ZXing.Common;
using ZXing.Windows.Compatibility;
using System.Linq; // nhớ thêm


namespace MiniMartHub
{
    public partial class QrScannerWindow : System.Windows.Window
    {
        private VideoCapture? _cap;
        private CancellationTokenSource? _cts;
        private Task? _captureTask;

        private readonly BarcodeReader _reader;

        // Điều khiển luồng quét
        private volatile bool _handlingScan = false;           // đang xử lý 1 kết quả quét
        private volatile bool _awaitingUserOK = false;         // đang chờ người dùng bấm OK
        private DateTime _lastScanAt = DateTime.MinValue;      // lần xử lý gần nhất
        private readonly TimeSpan _rescanDelay = TimeSpan.FromMilliseconds(1200); // cooldown

        public ObservableCollection<CartItem>? CartItemsScanned { get; set; }

        private readonly ProductService _productService = new();

        public string? ScannedText { get; private set; }

        public QrScannerWindow()
        {
            InitializeComponent();

            // Bind 1 lần: ObservableCollection tự cập nhật DataGrid khi Add/Remove
            CartItemsScannedDataGrid.ItemsSource = CartItemsScanned;

            // ZXing: chỉ đọc QR, cố gắng decode tốt
            _reader = new BarcodeReader
            {
                AutoRotate = true,
                Options = new DecodingOptions
                {
                    TryHarder = true,
                    PossibleFormats = new[] { BarcodeFormat.QR_CODE }
                }
            };
        }

        private async void Start_Click(object sender, RoutedEventArgs e)
        {
            if (_cap?.IsOpened() == true) return;

            int index = 0; // nếu có ComboBox chọn camera thì lấy index tại đây
            _cts = new CancellationTokenSource();

            _cap = new VideoCapture(index, VideoCaptureAPIs.DSHOW);
            if (!_cap.Open(index))
            {
                txtResult.Content = "Không mở được camera.";
                StopCamera();
                return;
            }

            // (tuỳ chọn) thiết lập độ phân giải
            _cap.FrameWidth = 1280;
            _cap.FrameHeight = 720;

            txtResult.Content = "Scanning...";

            // Chạy vòng quét trên thread nền
            _captureTask = Task.Run(() => CaptureLoop(_cts.Token));

            // (tuỳ) chờ một chút để UI kịp render
            await Task.Delay(50);
        }

        private void Stop_Click(object sender, RoutedEventArgs e)
        {
            StopCamera();                      // dừng vòng quét & release camera
            Close();    // đóng hẳn ứng dụng
        }

        private void CaptureLoop(CancellationToken ct)
        {
            using var frame = new Mat();

            while (!ct.IsCancellationRequested && _cap?.IsOpened() == true)
            {
                try
                {
                    // Nếu đang chờ người dùng bấm OK, tạm không decode (camera vẫn preview)
                    if (_awaitingUserOK) { Thread.Sleep(16); continue; }

                    if (!_cap.Read(frame) || frame.Empty())
                        continue;

                    // Preview (không block UI)
                    var preview = BitmapSourceConverter.ToBitmapSource(frame);
                    preview.Freeze();
                    Dispatcher.BeginInvoke(new Action(() => imgPreview.Source = preview), DispatcherPriority.Background);

                    // Đang xử lý 1 kết quả trước đó → bỏ qua để tránh đúp
                    if (_handlingScan) { Thread.Sleep(8); continue; }

                    // Decode QR
                    using var bmp = BitmapConverter.ToBitmap(frame);
                    var result = _reader.Decode(bmp);
                    if (result == null) { Thread.Sleep(4); continue; }

                    var text = result.Text?.Trim();
                    if (string.IsNullOrEmpty(text)) { Thread.Sleep(4); continue; }

                    // Chặn trùng liên tiếp trong khoảng cooldown
                    if (DateTime.UtcNow - _lastScanAt < _rescanDelay) { Thread.Sleep(4); continue; }

                    _handlingScan = true;
                    _lastScanAt = DateTime.UtcNow;
                    ScannedText = text;

                    // QR chỉ chứa productId (số)
                    if (int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out var productId))
                    {
                        var product = _productService.GetProductById(productId);

                        // Pause decode & hiển thị dialog cho người dùng
                        _awaitingUserOK = true;

                        Dispatcher.Invoke(() =>
                        {
                            if (product == null)
                            {
                                MessageBox.Show(
                                    $"Không tìm thấy sản phẩm ID = {productId}",
                                    "QR Scan",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Warning);

                                txtResult.Content = $"Không tìm thấy sản phẩm ID={productId}";
                            }
                            else
                            {
                                if (product.Status.Trim() == "Inactive")
                                {
                                    MessageBox.Show(
                                        $"Sản phẩm {product.Name} (ID: {productId}) không ACTIVE nên không thêm vào giỏ hàng được .\nBấm OK để quét tiếp.",
                                        "QR Scan",
                                        MessageBoxButton.OK,
                                        MessageBoxImage.Information);
                                }
                                else
                                {
                                    var existing = CartItemsScanned.FirstOrDefault(i => i.ProductId == productId);
                                    if (existing != null)
                                    {
                                        existing.Quantity += 1;
                                    }
                                    else
                                    {
                                        // TODO: nếu muốn gộp số lượng khi trùng ID, thay vì Add, tìm item cũ rồi +1 Quantity
                                        CartItemsScanned.Add(new CartItem
                                        {
                                            ProductId = productId,
                                            ProductName = product.Name,
                                            Price = product.Price,
                                            Quantity = 1,
                                        });
                                    }
                                    txtResult.Content = $"Đã thêm: {productId} - {product.Name}";

                                    MessageBox.Show(
                                        $"Đã thêm: {product.Name} (ID: {productId}).\nBấm OK để quét tiếp.",
                                        "QR Scan",
                                        MessageBoxButton.OK,
                                        MessageBoxImage.Information);
                                    CartItemsScannedDataGrid.ItemsSource = null;
                                    CartItemsScannedDataGrid.ItemsSource = CartItemsScanned;

                                }

                                // Sau khi người dùng bấm OK → cho phép quét tiếp
                                _lastScanAt = DateTime.UtcNow;   // reset mốc cooldown
                                _awaitingUserOK = false;
                            }
                        });
                    }
                    else
                    {
                        // Không phải số → cũng pause để báo và đợi OK
                        _awaitingUserOK = true;

                        Dispatcher.Invoke(() =>
                        {
                            MessageBox.Show(
                                "QR không phải là ProductId hợp lệ.",
                                "QR Scan",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);

                            txtResult.Content = "QR không hợp lệ";
                            _lastScanAt = DateTime.UtcNow;
                            _awaitingUserOK = false;
                        });
                    }
                }
                catch
                {
                    // Bỏ qua lỗi frame đơn lẻ
                }
                finally
                {
                    _handlingScan = false; // thả lock để vòng lặp tiếp tục
                }

                Thread.Sleep(16); // ~60fps; giảm tải CPU
            }
        }

        private void Window_Closing(object? sender, System.ComponentModel.CancelEventArgs e) => StopCamera();

        private void StopCamera()
        {
            try
            {
                _cts?.Cancel();

                // Chờ vòng quét kết thúc (tránh rò tài nguyên)
                try { _captureTask?.Wait(500); } catch { /* ignore */ }

                _cts?.Dispose();
                _cts = null;
                _captureTask = null;

                if (_cap != null)
                {
                    if (_cap.IsOpened()) _cap.Release();
                    _cap.Dispose();
                    _cap = null;
                }

                Dispatcher.BeginInvoke(new Action(() =>
                {
                    txtResult.Content = "Stopped";
                    imgPreview.Source = null;
                }), DispatcherPriority.Background);
            }
            catch
            {
                // ignore
            }
        }
    }
}
