﻿using BLL.Service;
using DAL.Entities;
using DAL.utils;
using Microsoft.Win32;
using Ookii.Dialogs.Wpf;
using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;   // <-- thêm cái này cho UserControl


namespace MiniMartHub
{
    public partial class ProductManagement : UserControl
    {
        private readonly ProductService _service;
        private ObservableCollection<Product> _products;

        public ProductManagement()
        {
            InitializeComponent();
            _service = new ProductService();
            LoadProducts();
        }
        private void UpdateProductStatus(Product product)
        {
            if (product.QuantityInStorage <= 0)
            {
                product.Status = "INACTIVE";
            }
            else
            {
                product.Status = "ACTIVE";
            }
        }

        private void LoadProducts()
        {
            try
            {
                List<Product> products = _service.GetProducts();
                _products = new ObservableCollection<Product>(products);
                dgProducts.ItemsSource = _products;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải sản phẩm: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ProductDialog dialog = new ProductDialog();
            dialog.ShowDialog();
            LoadProducts();
            //if (dialog.ShowDialog() == true)
            //{
            //    try
            //    {
            //        // cập nhật status theo quantity
            //        UpdateProductStatus(dialog.Product);

            //        _service.AddProduct(dialog.Product);
            //        _products.Add(dialog.Product);
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show("Không thể thêm sản phẩm: " + ex.Message);
            //    }
            //}
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            Product? product = dgProducts.SelectedItem as Product;
            if (product == null)
            {
                MessageBox.Show("Please select product before editing");
                return;
            }
            ProductDialog dialog = new ProductDialog();
            dialog.EditedOne = product;
            dialog.ShowDialog();
            LoadProducts();
            //if (dgProducts.SelectedItem is Product selected)
            //{
            //    ProductDialog dialog = new ProductDialog(selected);
            //    if (dialog.ShowDialog() == true)
            //    {
            //        try
            //        {
            //            // cập nhật status theo quantity
            //            UpdateProductStatus(dialog.Product);

            //            _service.UpdateProduct(dialog.Product);

            //            int index = _products.IndexOf(selected);
            //            if (index >= 0)
            //            {
            //                _products[index] = dialog.Product;
            //            }
            //        }
            //        catch (Exception ex)
            //        {
            //            MessageBox.Show("Không thể cập nhật sản phẩm: " + ex.Message);
            //        }
            //    }
            //}
            //else
            //{
            //    MessageBox.Show("Vui lòng chọn sản phẩm để sửa.");
            //}
        }


        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (dgProducts.SelectedItem is Product selected)
            {
                if (MessageBox.Show($"Bạn có chắc chắn muốn INACTIVE SP này không: {selected.Name}?",
                    "Xác nhận", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    selected.Status = "Inactive";
                    _service.Update(selected);
                    LoadProducts();
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn sản phẩm để INACTIVE.");
            }
        }
        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadProducts();
        }

        private void ActiveButton_Click(object sender, RoutedEventArgs e)
        {
            if (dgProducts.SelectedItem is Product selected)
            {
                if (selected.QuantityInStorage <= 0)
                {
                    MessageBox.Show("Bạn không thể active sản phẩm có số lượng = 0.");
                    return;
                }
                selected.Status = "Active";
                _service.Update(selected);
                LoadProducts();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn sản phẩm để ACTIVE.");
            }
        }

        private void ExportButton_Click(object sender, RoutedEventArgs e)
        {
            var saveFileDialog = new SaveFileDialog
            {
                Filter = "Excel Workbook (*.xlsx)|*.xlsx",
                Title = "Lưu file Excel"
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                try
                {
                    _service.ExportProductsToExcelWithQr(saveFileDialog.FileName);
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show("Lỗi export: " + ex.Message, "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private async void btnGetFolderImages_Click(object sender, RoutedEventArgs e)
        {
            var btn = (Button)sender;
            btn.IsEnabled = false;
            Mouse.OverrideCursor = Cursors.Wait;

            try
            {
                string source = QRCodeService.GetQRCodeFolder();
                if (!Directory.Exists(source))
                {
                    MessageBox.Show($"Không tìm thấy thư mục nguồn:\n{source}",
                        "Thông báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var dlg = new VistaFolderBrowserDialog
                {
                    Description = "Chọn thư mục đích để lưu/copy toàn bộ ảnh QR",
                    UseDescriptionForTitle = true,
                    ShowNewFolderButton = true
                };

                // Lấy Window chứa UserControl làm owner
                Window? owner = Window.GetWindow(this);
                bool? ok = owner is null ? dlg.ShowDialog() : dlg.ShowDialog(owner);
                if (ok != true || string.IsNullOrWhiteSpace(dlg.SelectedPath)) return;

                string destRoot = dlg.SelectedPath;
                string dest = Path.Combine(destRoot, $"QRCodes_{DateTime.Now:yyyyMMdd_HHmmss}");
                Directory.CreateDirectory(dest);

                var (files, dirs) = await Task.Run(() => CopyDirectory(source, dest, overwrite: true));

                MessageBox.Show(
                    $"Đã sao chép thư mục hình ảnh tới:\n{dest}",
                    "Hoàn tất", MessageBoxButton.OK, MessageBoxImage.Information);

                try { Process.Start("explorer.exe", dest); } catch { /* ignore */ }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi sao chép: " + ex.Message, "Lỗi",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                Mouse.OverrideCursor = null;
                btn.IsEnabled = true;
            }
        }


        /// <summary>
        /// Copy toàn bộ cây thư mục (file + subfolder). Trả về (số file, số thư mục con).
        /// </summary>
        private static (int files, int dirs) CopyDirectory(string sourceDir, string destDir, bool overwrite)
        {
            int filesCount = 0, dirsCount = 0;

            // Tạo các subfolder
            foreach (var dir in Directory.GetDirectories(sourceDir, "*", SearchOption.AllDirectories))
            {
                var targetSub = dir.Replace(sourceDir, destDir);
                Directory.CreateDirectory(targetSub);
                dirsCount++;
            }

            // Copy các file
            foreach (var file in Directory.GetFiles(sourceDir, "*", SearchOption.AllDirectories))
            {
                var targetFile = file.Replace(sourceDir, destDir);
                Directory.CreateDirectory(Path.GetDirectoryName(targetFile)!);
                File.Copy(file, targetFile, overwrite);
                filesCount++;
            }

            return (filesCount, dirsCount);
        }
    }
 }