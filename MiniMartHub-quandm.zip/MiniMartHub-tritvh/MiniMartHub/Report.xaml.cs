﻿using BLL.Service;
using BLL.Service.BLL.Service;
using DAL.Entities;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Win32;
using OxyPlot;
using OxyPlot.Series;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MiniMartHub
{
    /// <summary>
    /// Interaction logic for Report.xaml
    /// </summary>
    public partial class Report : UserControl
    {
        private OrderService _orderService = new();
        private ExportService _exportService = new();
        public Report()
        {
            InitializeComponent();

        }

        private void btnShowReport_Click(object sender, RoutedEventArgs e)
        {
            const int TOP_N = 5;

            var fromDate = dpFromDate.SelectedDate ?? DateTime.Now.AddMonths(-1);
            var toDate = dpToDate.SelectedDate ?? DateTime.Now;

            var orders = _orderService.GetOrdersByDateRange(fromDate, toDate) ?? new List<Order>();

            // Không có dữ liệu
            if (!orders.Any())
            {
                totalRevenueLabel.Content = "0 VNĐ";
                totalOrdersLabel.Content = "0";
                top5DataGrid.ItemsSource = null;

                Plot.Model = new OxyPlot.PlotModel { Title = "No data" };
                Plot.InvalidatePlot(true);
                return;
            }

            var totalRevenue = orders.Sum(o => o.TotalPrice);
            var totalOrders = orders.Count;

            var topProducts = orders
                .Where(o => o.OrderDetails != null)
                .SelectMany(o => o.OrderDetails!)
                .Where(od => od.Product != null)
                .GroupBy(od => od.Product!.Name)
                .Select(g => new
                {
                    ProductName = g.Key,
                    TotalRevenue = g.Sum(od => od.TotalPriceOfProduct)
                })
                .Where(x => x.TotalRevenue > 0)
                .OrderByDescending(x => x.TotalRevenue)
                .Take(TOP_N)
                .ToList();

            // cập nhật tổng quan + bảng
            totalRevenueLabel.Content = $"{totalRevenue:N0} VNĐ";
            totalOrdersLabel.Content = totalOrders.ToString();
            top5DataGrid.ItemsSource = topProducts;

            // Vẽ pie chart: dùng nhãn ngoài để lát rất nhỏ vẫn thấy, và "tách" lát <1%
            var model = new OxyPlot.PlotModel();
            var series = new OxyPlot.Series.PieSeries
            {
                AngleSpan = 360,
                StartAngle = 0,
                StrokeThickness = 1,
                InsideLabelFormat = null,                    // tránh 100% che lát khác
                OutsideLabelFormat = "{1}: {2:0.0000}%",      // {1}=Label, {2}=%
                TickHorizontalLength = 8,
                TickRadialLength = 16,
            };

            // Tooltip khi hover (tracker):
            // {0}=Series title, {1}=Slice label, {2}=Value, {3}=Percent
            series.TrackerFormatString = "{1}: {2:N0} VNĐ ({3:0.0000}%)";

            double sum = topProducts.Sum(p => (double)p.TotalRevenue);
            foreach (var p in topProducts)
            {
                double value = (double)p.TotalRevenue;
                double percent = sum > 0 ? value / sum * 100.0 : 0;

                var slice = new OxyPlot.Series.PieSlice(p.ProductName, value)
                {
                    IsExploded = percent < 1.0
                };
                series.Slices.Add(slice);
            }

            model.Series.Add(series);
            Plot.Model = model;
            Plot.InvalidatePlot(true);
        }


        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            dpFromDate.Text = DateTime.Now.AddMonths(-1).ToString();
            dpToDate.Text=  DateTime.Now.ToString();
        }

        private void btnExportExcel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var fromDate = dpFromDate.SelectedDate ?? DateTime.Now.AddMonths(-1);
                var toDate = dpToDate.SelectedDate ?? DateTime.Now;

                var orders = _orderService.GetOrdersByDateRange(fromDate, toDate);

                if (!orders.Any())
                {
                    MessageBox.Show("No orders found in the selected date range.", "No Data",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                var excelData = _exportService.ExportRevenueToExcel(orders, fromDate, toDate);

                SaveFileDialog saveDialog = new SaveFileDialog
                {
                    Filter = "Excel files (*.xlsx)|*.xlsx",
                    FileName = $"Revenue_Report_{fromDate:yyyyMM}_{toDate:yyyyMM}.xlsx",
                    DefaultExt = "xlsx"
                };

                if (saveDialog.ShowDialog() == true)
                {
                    File.WriteAllBytes(saveDialog.FileName, excelData);
                    MessageBox.Show($"Excel report exported successfully!\nLocation: {saveDialog.FileName}",
                        "Export Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Export failed: {ex.Message}", "Export Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
