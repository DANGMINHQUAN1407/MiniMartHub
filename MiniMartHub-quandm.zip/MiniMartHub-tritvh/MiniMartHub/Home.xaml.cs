﻿using DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MiniMartHub
{
    /// <summary>
    /// Interaction logic for Home.xaml
    /// </summary>
    public partial class Home : Window
    {
        private UserManagement? _userManagement;
        private OrderManagement? _orderManagement;
        private Report? _report;
        private ProductManagement? _productManagement;

        public Account? Author;

        public Home()
        {
            InitializeComponent();
        }

        private void dgUserManagement_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
           
                _userManagement = new UserManagement();
                _userManagement.Author = Author;
            
                 MainContentControl.Content = _userManagement;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.Icon = new BitmapImage(new Uri("pack://application:,,,/MiniMartHub;component/imgs/pngtree-mini-mart-shop-building-vector-png-png-image_7667348.png"));
            if (Author != null)
            {
                if(Author.Role == 3)
                {
                    dgUserManagement.Visibility = Visibility.Collapsed;
                }
                if(Author.Role == 2)
                {
                    dgUserManagement.Visibility = Visibility.Collapsed;
                    productManagement.Visibility = Visibility.Collapsed;
                    ReportControl.Visibility = Visibility.Collapsed;
                }
                LabelHello.Text = "Hello, " + Author.Name;
            }
        }

        private void dgProductManagement_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            
                _orderManagement = new OrderManagement();
                _orderManagement.Author = Author;
            
            MainContentControl.Content = _orderManagement;
        }

        private void ReportControl_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            
                _report = new Report();
            
            MainContentControl.Content = _report;
        }

        private void productManagement_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
                _productManagement = new ProductManagement();
            
            MainContentControl.Content = _productManagement;
        }

        private void LogOutBtn_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            LoginWindow login = new LoginWindow();
            login.Show();
            this.Close();
        }
    }
}
