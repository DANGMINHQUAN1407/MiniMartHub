﻿using BLL.Service;
using DAL.Entities;
using DAL.utils;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace MiniMartHub
{
    public partial class ProductDialog : Window
    {
        public Product? EditedOne { get; set; }
        private ProductService _productService = new(); 
        public ProductDialog()
        {
            InitializeComponent();
        }

        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            var btn = (Button)sender;
            btn.IsEnabled = false;
            var oldText = btn.Content;
            btn.Content = "Saving...";

            try
            {
                string name = txtName.Text.Trim();
                string priceText = txtPrice.Text.Trim();
                string quantityText = txtQuantity.Text.Trim();

                if (string.IsNullOrWhiteSpace(name) ||
                    string.IsNullOrWhiteSpace(priceText) ||
                    string.IsNullOrWhiteSpace(quantityText))
                {
                    MessageBox.Show("All fields are required");
                    return;
                }
                if (!int.TryParse(priceText, out int price))
                {
                    MessageBox.Show("You must enter numeric number for price field");
                    return;
                }
                if (!int.TryParse(quantityText, out int quantity))
                {
                    MessageBox.Show("You must enter numeric number for quantity field");
                    return;
                }

                string status = quantity <= 0 ? "Inactive" : "Active";

                if(EditedOne != null)
                {
                    var updatedOned = new Product
                    {
                        Id = EditedOne.Id,
                        Name = name,
                        Price = price,
                        QuantityInStorage = quantity,
                        Status = status,
                        QrimageUrl = EditedOne.QrimageUrl,
                    };
                    _productService.Update(updatedOned);
                    Close();
                    return;
                }

                var product = new Product
                {
                    Name = name,
                    Price = price,
                    QuantityInStorage = quantity,
                    Status = status,
                    QrimageUrl = "temp.png"
                };

                // ĐỢI lưu xong
                await _productService.AddWithQrAsync(product);

                // OK -> đóng form
                Close();
            }
            catch (DbUpdateException ex)
            {
                MessageBox.Show(ex.InnerException?.Message ?? ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                btn.Content = oldText;
                btn.IsEnabled = true;   // phòng khi có lỗi thì bật lại
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (EditedOne != null)
            {
                txtQr.Visibility = Visibility.Collapsed;
                StatusLabel.Content = EditedOne.Status;

                txtName.Text = EditedOne.Name;
                txtPrice.Text = EditedOne.Price.ToString();
                txtQuantity.Text = EditedOne.QuantityInStorage.ToString();
                string fullPath = QRCodeService.GetQRCodeFullPath(EditedOne.QrimageUrl);
                if (!System.IO.File.Exists(fullPath))
                {
                    MessageBox.Show("Failed To Load Image");
                    return;
                }
                qR.Source = new BitmapImage(new Uri(fullPath));
                qR.Stretch = System.Windows.Media.Stretch.Uniform;
                return;
            }
            StatusHeader.Visibility = Visibility.Collapsed;
            StatusLabel.Visibility = Visibility.Collapsed;
        }
    }
}
