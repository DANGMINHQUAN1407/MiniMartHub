﻿using BLL.Service;
using DAL.Entities;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MiniMartHub
{
    /// <summary>
    /// Interaction logic for UserProperties.xaml
    /// </summary>
    public partial class UserProperties : Window
    {
        private RoleService _roleService;
        private AccountService _accountService;

        public Account? AccountInfo { get; set; }

        public UserProperties()
        {
            InitializeComponent();
            _roleService = new RoleService();
            _accountService = new AccountService();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            string email = txtEmail.Text.Trim();
            string name = txtName.Text.Trim();
            string phoneNumberInput = txtPhoneNumber.Text.Trim();
            if (email.IsNullOrEmpty() || name.IsNullOrEmpty() || phoneNumberInput.IsNullOrEmpty() )
            {
                MessageBox.Show("Please enter all field", "Required Field", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            DateOnly dateOfBirth;
            if (!dateOfBirthInput.SelectedDate.HasValue)
            {
                MessageBox.Show("Please enter all field", "Required Field", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            int phoneNumber;
            try
            {
                phoneNumber = Convert.ToInt32(phoneNumberInput);
            }
            catch (FormatException)
            {
                MessageBox.Show("Phone number must be numeric.", "Invalid Input", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (phoneNumberInput.Length != 10)
            {
                MessageBox.Show("Phone number must be 10 digits", "Invalid Field", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            dateOfBirth = DateOnly.FromDateTime(dateOfBirthInput.SelectedDate.Value);
            int selectedRoleId;
            if (AccountInfo != null)
            {
                if (AccountInfo.Role != 1)
                {
                    selectedRoleId = (int)cbRole.SelectedValue;
                }
                else selectedRoleId = 1;

                    Account updateAccount = new Account()
                    { Email = email, Name = name, Password = AccountInfo.Password, PhoneNumber = phoneNumber, Role = selectedRoleId, DateOfBirth = dateOfBirth, Status = "ACTIVE" }; ;
                updateAccount.Id = AccountInfo.Id;
                _accountService.UpdateAccount(updateAccount);
                Close();
                return;
            }

            selectedRoleId = (int)cbRole.SelectedValue;

            if (_accountService.IsExistEmail(email))
            {
                MessageBox.Show("Email already existed", "Invalid Field", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (_accountService.IsExistPhoneNumber(phoneNumber))
            {
                MessageBox.Show("Phone Number already existed", "Invalid Field", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            Account createAccount = new()
            { Email = email, Name = name, Password = "123456", PhoneNumber = phoneNumber, Role = selectedRoleId, DateOfBirth = dateOfBirth, Status = "ACTIVE" };
            _accountService.CreateAccount(createAccount);
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void LoadRoles()
        {
            cbRole.ItemsSource = _roleService.GetRoles();
            cbRole.DisplayMemberPath = "Name";
            cbRole.SelectedValuePath = "Id";
            cbRole.SelectedIndex = 0;
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            LoadRoles();
            if (AccountInfo != null)
            {
                txtEmail.Text = AccountInfo.Email;
                txtName.Text = AccountInfo.Name;
                txtPhoneNumber.Text = "0"+AccountInfo.PhoneNumber.ToString();
                dateOfBirthInput.Text = AccountInfo.DateOfBirth.ToString();
                cbRole.SelectedValue = AccountInfo.Role;
                if(AccountInfo.Role == 1)
                {
                    RoleContainer.Visibility = Visibility.Collapsed;
                    LabelRoleAdmin.Visibility = Visibility.Visible;
                }
            }
        }
    }
}
