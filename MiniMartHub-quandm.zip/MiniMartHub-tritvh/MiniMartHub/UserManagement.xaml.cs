﻿using BLL.Service;
using DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MiniMartHub
{
    /// <summary>
    /// Interaction logic for UserManagement.xaml
    /// </summary>
    public partial class UserManagement : UserControl
    {
        private AccountService _accountService;

        public Account? Author { get; set; } 

        public UserManagement()
        {
            InitializeComponent();
            _accountService = new AccountService();
        }

        private void btnCreate_Click(object sender, RoutedEventArgs e)
        {
            UserProperties userProperties = new UserProperties();
            userProperties.ShowDialog();
            btnUpdate.Visibility = Visibility.Visible;
            btnDelete.Visibility = Visibility.Visible;
            btnBan.Visibility = Visibility.Visible;
            btnUnBan.Visibility = Visibility.Visible;
            LoadUsers();
        }
        public void LoadUsers()
        {
            DataGridAccounts.ItemsSource = null;
            DataGridAccounts.ItemsSource = _accountService.GetAccounts();
        }
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            LoadUsers();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            Account? selectedAccount = DataGridAccounts.SelectedItem as Account;
            if (selectedAccount == null)
            {
                MessageBox.Show("Please choose account", "Choice", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (selectedAccount.Role == 1)
            {
                MessageBox.Show("Cannot delete admin account", "DELETE", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            MessageBoxResult result = MessageBox.Show("Do you sure want to delete this account?", "DELETE", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.No)
            {
                return ;
            }
            _accountService.DeleteAccount(selectedAccount);
            btnUpdate.Visibility = Visibility.Visible;
            btnDelete.Visibility = Visibility.Visible;
            btnBan.Visibility = Visibility.Visible;
            btnUnBan.Visibility = Visibility.Visible;
            LoadUsers();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Account? selectedAccount = DataGridAccounts.SelectedItem as Account;
            if (selectedAccount == null)
            {
                MessageBox.Show("Please choose account", "Choice", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            UserProperties userProperties = new UserProperties();
            userProperties.AccountInfo = selectedAccount;
            userProperties.ShowDialog();
            btnUpdate.Visibility = Visibility.Visible;
            btnDelete.Visibility = Visibility.Visible;
            btnBan.Visibility = Visibility.Visible;
            btnUnBan.Visibility = Visibility.Visible;
            LoadUsers();
        }

        private void DataGridAccounts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Account? selectedAccount = DataGridAccounts.SelectedItem as Account;
            if(selectedAccount == null)
            {
                return;
            }

            if(selectedAccount.Role == 1)
            {
                btnBan.Visibility = Visibility.Hidden;
                btnUnBan.Visibility = Visibility.Hidden;
                btnUpdate.Visibility = Visibility.Visible;
                btnDelete.Visibility = Visibility.Hidden;
                return;
            }

            if (selectedAccount.Status.Trim().ToUpper() == "BANNED")
            {
                btnUpdate.Visibility = Visibility.Hidden;
                btnDelete.Visibility = Visibility.Visible;
                btnBan.Visibility = Visibility.Hidden;
                btnUnBan.Visibility = Visibility.Visible;
                return;
            }
            if (selectedAccount.Status.Trim().ToUpper() == "ACTIVE")
            {
                btnUpdate.Visibility = Visibility.Visible;
                btnDelete.Visibility = Visibility.Visible;
                btnBan.Visibility = Visibility.Visible;
                btnUnBan.Visibility = Visibility.Hidden;
                return;
            }
        }

        private void btnBan_Click(object sender, RoutedEventArgs e)
        {
            Account? selectedAccount = DataGridAccounts.SelectedItem as Account;
            if (selectedAccount == null)
            {
                MessageBox.Show("Please choose account", "Choice", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            selectedAccount.Status = "BANNED";
            _accountService.UpdateAccount(selectedAccount);
            btnUpdate.Visibility = Visibility.Visible;
            btnDelete.Visibility = Visibility.Visible;
            btnBan.Visibility = Visibility.Visible;
            btnUnBan.Visibility = Visibility.Visible;
            LoadUsers();
        }

        private void btnUnBan_Click(object sender, RoutedEventArgs e)
        {
            Account? selectedAccount = DataGridAccounts.SelectedItem as Account;
            if (selectedAccount == null)
            {
                MessageBox.Show("Please choose account", "Choice", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            selectedAccount.Status = "ACTIVE";
            _accountService.UpdateAccount(selectedAccount);
            btnUpdate.Visibility = Visibility.Visible;
            btnDelete.Visibility = Visibility.Visible;
            btnBan.Visibility = Visibility.Visible;
            btnUnBan.Visibility = Visibility.Visible;
            LoadUsers();
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            string search = txtSearch.Text.Trim();
            DataGridAccounts.ItemsSource = null;
            DataGridAccounts.ItemsSource = _accountService.SearchAccounts(search);
        }
    }
}
