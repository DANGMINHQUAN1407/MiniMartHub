﻿using BLL.Service;
using DAL.Entities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace MiniMartHub
{
    public partial class OrderManagement : UserControl
    {
        private ProductService _productService;
        private OrderService _orderService;
        private ObservableCollection<CartItem> _cartItems;

        public Account? Author { get; set; }
        public OrderManagement()
        {
            InitializeComponent();
            _productService = new ProductService();
            _orderService = new OrderService();
            _cartItems = new ObservableCollection<CartItem>();
            lvCart.ItemsSource = _cartItems;
            LoadProducts();
            LoadOrders();
        }

        private void LoadProducts()
        {
            var products = _productService.GetAllAvailableProducts();
            dgProducts.ItemsSource = products;
        }

        private void LoadOrders()
        {
            var orders = _orderService.GetAllOrders();
            dgOrders.ItemsSource = orders;
        }

        // Search methods
        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            string searchTerm = txtSearch.Text.Trim();

            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                LoadProducts(); // Load all products if search is empty
            }
            else
            {
                var searchResults = _productService.SearchProductsByName(searchTerm);
                dgProducts.ItemsSource = searchResults;

                // Update GroupBox header to show result count
                UpdateProductsHeader(searchResults.Count, true);
            }
        }

        private void btnClearSearch_Click(object sender, RoutedEventArgs e)
        {
            txtSearch.Text = "";
            LoadProducts(); // Load all products
            UpdateProductsHeader(0, false);
        }

        private void UpdateProductsHeader(int resultCount, bool isFiltered)
        {
            var groupBox = dgProducts.Parent as GroupBox;
            if (groupBox != null)
            {
                if (isFiltered)
                {
                    groupBox.Header = $"Available Products ({resultCount} found)";
                }
                else
                {
                    groupBox.Header = "Available Products";
                }
            }
        }

        // Existing methods...
        private void btnAddToCart_Click(object sender, RoutedEventArgs e)
        {
            if (dgProducts.SelectedItem is Product selectedProduct)
            {
                if (int.TryParse(txtQuantity.Text, out int quantity) && quantity > 0)
                {
                    if (quantity > selectedProduct.QuantityInStorage)
                    {
                        MessageBox.Show($"Not enough stock! Available: {selectedProduct.QuantityInStorage}", "Stock Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    // Check if product already in cart
                    var existingItem = _cartItems.FirstOrDefault(c => c.ProductId == selectedProduct.Id);
                    if (existingItem != null)
                    {
                        if (existingItem.Quantity + quantity > selectedProduct.QuantityInStorage)
                        {
                            MessageBox.Show($"Total quantity would exceed stock! Available: {selectedProduct.QuantityInStorage}, Current in cart: {existingItem.Quantity}", "Stock Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                            return;
                        }
                        existingItem.Quantity += quantity;
                    }
                    else
                    {
                        _cartItems.Add(new CartItem
                        {
                            ProductId = selectedProduct.Id,
                            ProductName = selectedProduct.Name,
                            Price = selectedProduct.Price,
                            Quantity = quantity
                        });
                    }

                    UpdateTotalPrice();
                    lvCart.ItemsSource = null;
                    lvCart.ItemsSource = _cartItems;
                    txtQuantity.Text = "1";
                }
                else
                {
                    MessageBox.Show("Please enter a valid quantity!", "Input Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                MessageBox.Show("Please select a product!", "Selection Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void btnRemoveFromCart_Click(object sender, RoutedEventArgs e)
        {
            if (lvCart.SelectedItem is CartItem selectedItem)
            {
                _cartItems.Remove(selectedItem);
                UpdateTotalPrice();
            }
        }

        private void btnClearCart_Click(object sender, RoutedEventArgs e)
        {
            _cartItems.Clear();
            UpdateTotalPrice();
 
        }

        private void btnCreateOrder_Click(object sender, RoutedEventArgs e)
        {
            if (_cartItems.Count == 0)
            {
                MessageBox.Show("Cart is empty!", "Cart Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            //////////////
            bool success = _orderService.CreateOrder(Author.Id, _cartItems.ToList());
            
            if (success)
            {
                MessageBox.Show("Order created successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                _cartItems.Clear();
                UpdateTotalPrice();
                LoadProducts(); // Refresh to show updated stock
                LoadOrders(); // Refresh orders list
            }
            else
            {
                MessageBox.Show("Failed to create order. Please check product availability.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnRefreshOrders_Click(object sender, RoutedEventArgs e)
        {
            LoadOrders();
        }

        private void btnViewOrderDetails_Click(object sender, RoutedEventArgs e)
        {
            if (dgOrders.SelectedItem is Order selectedOrder)
            {
                // Mở modal window
                var orderDetailsWindow = new OrderDetailsWindow(selectedOrder);
                orderDetailsWindow.Owner = Window.GetWindow(this);

                orderDetailsWindow.OrderCompleted += OrderDetailsWindow_OrderCompleted;

                orderDetailsWindow.ShowDialog();

                LoadOrders();
                LoadProducts();

            }
            else
            {
                MessageBox.Show("Please select an order!", "Selection Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void OrderDetailsWindow_OrderCompleted(object sender, EventArgs e)
        {
            // Refresh products list để show updated stock
            LoadProducts();

            // Optionally refresh orders list nếu cần
            // LoadOrders();
        }

     

        private void UpdateTotalPrice()
        {
            int total = _cartItems.Sum(item => item.TotalPrice);
            lblTotal.Text = $"Total: ${total}";
        }

        private void dgOrders_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Order? order = dgOrders.SelectedItem as Order;
            if(order != null)
            {
                if (order.Status.Trim().Equals("Paid"))
                {
                    btnCancelOrder.Visibility = Visibility.Hidden;
                } else
                {
                    btnCancelOrder.Visibility = Visibility.Visible;
                }

            }
        }

        private void btnCancelOrder_Click(object sender, RoutedEventArgs e)
        {
            Order? order = dgOrders.SelectedItem as Order;
            if(order == null)
            {
                MessageBox.Show("Please select an order!", "Selection Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            MessageBoxResult result = MessageBox.Show("");
            _orderService.DeleteOrder(order.Id);
            LoadOrders();
        }

        private void btnScanQRProduct_Click(object sender, RoutedEventArgs e)
        {
            QrScannerWindow qrScannerWindow = new QrScannerWindow();
            qrScannerWindow.CartItemsScanned = _cartItems;
            qrScannerWindow.ShowDialog();
            lvCart.ItemsSource = null;
            lvCart.ItemsSource = _cartItems;
            UpdateTotalPrice();
        }
    }
}