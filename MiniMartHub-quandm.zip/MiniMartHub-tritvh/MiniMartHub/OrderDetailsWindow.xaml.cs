﻿using BLL.Service;
using DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace MiniMartHub
{
    public partial class OrderDetailsWindow : Window
    {
        private OrderService _orderService;
        private ProductService _productService;
        private Order _order;

        // Thêm event để notify parent window
        public event EventHandler OrderCompleted;

        public OrderDetailsWindow(Order order)
        {
            InitializeComponent();
            _orderService = new OrderService();
            _productService = new ProductService();
            _order = order;
            if (order.Status.Trim().Equals("Paid"))
            {
                btnCompleteOrder.Visibility = Visibility.Hidden ;
            }
            LoadOrderDetails();
        }

        private void LoadOrderDetails()
        {
            if (_order == null) return;

            // Set order information
            txtOrderTitle.Text = $"Order #{_order.Id} Details";
            txtOrderId.Text = _order.Id.ToString();
            txtCreatedDate.Text = _order.CreatedDate.ToString("dd/MM/yyyy HH:mm");
            txtCreatedBy.Text = $"User ID: {_order.CreatedBy}";
            txtTotalPrice.Text = $"${_order.TotalPrice:F2}";
            txtFinalTotal.Text = $"${_order.TotalPrice:F2}";

            // Get order details
            var orderDetails = _orderService.GetOrderDetails(_order.Id);

            // Create display objects with product information
            var displayDetails = orderDetails.Select(od =>
            {
                var product = _productService.GetProductById(od.ProductId);
                return new OrderDetailDisplay
                {
                    ProductName = product?.Name ?? "Unknown Product",
                    UnitPrice = product?.Price ?? 0,
                    Quantity = od.Quantity,
                    TotalPriceOfProduct = od.TotalPriceOfProduct
                };
            }).ToList();

            // Bind to DataGrid
            dgOrderDetails.ItemsSource = displayDetails;

            // Calculate total items
            int totalItems = displayDetails.Sum(d => d.Quantity);
            txtTotalItems.Text = totalItems.ToString();
        }

        private  void btnCompleteOrder_Click(object sender, RoutedEventArgs e)
        {
           
                try
                {
                    bool success = _orderService.CompleteOrderAndUpdateStock(_order.Id);

                    if (success)
                    {
                        MessageBox.Show(
                            "Order completed successfully!",
                            "Success",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);
                   
                    }
                    else
                    {
                        MessageBox.Show(
                            "Failed to complete order. Some products may not have enough stock.",
                            "Error",
                            MessageBoxButton.OK,
                            MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(
                        $"An error occurred while completing the order:\n{ex.Message}",
                        "Error",
                        MessageBoxButton.OK,
                        MessageBoxImage.Error);
                }
            finally
            {
                Close();
            }
            
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }

    // Helper class for displaying order details
    public class OrderDetailDisplay
    {
        public string ProductName { get; set; } = string.Empty;
        public int UnitPrice { get; set; }
        public int Quantity { get; set; }
        public int TotalPriceOfProduct { get; set; }
    }
}